var searchData=
[
  ['error_5fmessage_476',['error_message',['../classcsyn_1_1_c_syn_exception.html#a08b8591cbd5aac87f7d927d315689869',1,'csyn::CSynException']]]
];
