var searchData=
[
  ['removekernel_372',['removeKernel',['../classcsyn_1_1_c_syn_manager.html#aac3983be18dbd4c28f3698a38e42c8fe',1,'csyn::CSynManager']]],
  ['removekernellist_373',['removeKernelList',['../classcsyn_1_1_c_syn_manager.html#ab1f5abd675252befbd0ef3d35367f05e',1,'csyn::CSynManager']]],
  ['removemodule_374',['removeModule',['../classcsyn_1_1_c_syn_manager.html#aa0bf637c333b6c011307d73ba8929892',1,'csyn::CSynManager::removeModule(const std::string &amp;module, const std::string &amp;moduleVersion, int moduleType)'],['../classcsyn_1_1_c_syn_manager.html#a57a6cfd51eb593afdf855eba93c69c9f',1,'csyn::CSynManager::removeModule(const std::shared_ptr&lt; Module &gt; &amp;module)']]],
  ['runjob_375',['runJob',['../classcsyn_1_1_c_syn_manager.html#a6968c813e5008cc7091078ecbf9a75be',1,'csyn::CSynManager']]],
  ['runjobasync_376',['runJobAsync',['../classcsyn_1_1_c_syn_manager.html#a520705bf07bb7bacb907b10780f0b481',1,'csyn::CSynManager']]],
  ['runjobasyncandwait_377',['runJobAsyncAndWait',['../classcsyn_1_1_c_syn_manager.html#a98f738a55fe97ca4c66b757a5122fc10',1,'csyn::CSynManager']]]
];
