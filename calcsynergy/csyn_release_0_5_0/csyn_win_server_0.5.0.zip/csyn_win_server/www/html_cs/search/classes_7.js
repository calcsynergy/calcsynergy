var searchData=
[
  ['securitymanager_214',['SecurityManager',['../class_c_syn_1_1_security_manager.html',1,'CSyn']]]
];
