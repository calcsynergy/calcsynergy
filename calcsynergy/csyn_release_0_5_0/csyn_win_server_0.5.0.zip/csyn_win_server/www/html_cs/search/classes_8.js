var searchData=
[
  ['task_215',['Task',['../class_c_syn_1_1_task.html',1,'CSyn']]],
  ['taskresult_216',['TaskResult',['../class_c_syn_1_1_task_result.html',1,'CSyn']]],
  ['taskstatus_217',['TaskStatus',['../class_c_syn_1_1_task_status.html',1,'CSyn']]]
];
