var searchData=
[
  ['task_174',['Task',['../classcsyn_1_1_task.html',1,'csyn::Task'],['../classcsyn_1_1_task.html#a30240eba757a3a77c8c8bee75e1b0a6a',1,'csyn::Task::Task()']]],
  ['taskresult_175',['TaskResult',['../classcsyn_1_1_task_result.html',1,'csyn::TaskResult'],['../classcsyn_1_1_task_result.html#af82b0ae8df29ac3bea5b4cdfe5f75bad',1,'csyn::TaskResult::TaskResult(const std::string &amp;taskName, const std::string &amp;uuid, std::vector&lt; std::shared_ptr&lt; Value &gt;&gt; &amp;valueList)'],['../classcsyn_1_1_task_result.html#ae32f699985047f8aa2f4bd7630662cd9',1,'csyn::TaskResult::TaskResult(const std::string &amp;taskName, const std::string &amp;uuid)']]],
  ['taskstatus_176',['TaskStatus',['../classcsyn_1_1_task_status.html',1,'csyn::TaskStatus'],['../classcsyn_1_1_task_status.html#a320142f5a0b5f072c6fb8d5e69cb7ea8',1,'csyn::TaskStatus::TaskStatus()']]]
];
