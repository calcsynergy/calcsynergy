var searchData=
[
  ['job_110',['Job',['../class_c_syn_1_1_job.html',1,'CSyn.Job'],['../class_c_syn_1_1_job.html#a3ed572bbe78443f81738112fa493630b',1,'CSyn.Job.Job()']]],
  ['jobexecutionstatus_111',['JobExecutionStatus',['../namespace_c_syn.html#a06ecb0c29da0f8af48a0809eac8f95cb',1,'CSyn']]],
  ['jobresult_112',['JobResult',['../class_c_syn_1_1_job_result.html',1,'CSyn.JobResult'],['../class_c_syn_1_1_job_result.html#a295fd1293d9e91875041780f923a1d7c',1,'CSyn.JobResult.JobResult()']]],
  ['jobstatus_113',['JobStatus',['../class_c_syn_1_1_job_status.html',1,'CSyn.JobStatus'],['../class_c_syn_1_1_job_status.html#aa83d05edc106c1773c7e80a13446aa41',1,'CSyn.JobStatus.JobStatus()']]]
];
