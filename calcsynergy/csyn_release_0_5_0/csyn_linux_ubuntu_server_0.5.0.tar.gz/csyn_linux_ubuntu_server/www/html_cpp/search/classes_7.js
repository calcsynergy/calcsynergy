var searchData=
[
  ['securitymanager_239',['SecurityManager',['../classcsyn_1_1_security_manager.html',1,'csyn']]]
];
