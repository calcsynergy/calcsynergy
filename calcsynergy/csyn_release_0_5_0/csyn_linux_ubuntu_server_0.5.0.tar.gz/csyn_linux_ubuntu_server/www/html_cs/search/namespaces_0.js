var searchData=
[
  ['csyn_231',['CSyn',['../namespace_c_syn.html',1,'']]]
];
