var searchData=
[
  ['uploadkernellist_166',['uploadKernelList',['../classcsyn_1_1_c_syn_manager.html#a3c0e079beb88406d16e8f530d4e6f13e',1,'csyn::CSynManager']]],
  ['uploadmodule_167',['uploadModule',['../classcsyn_1_1_c_syn_manager.html#a3530cceb97242cd53ab24dfabd0d1934',1,'csyn::CSynManager::uploadModule(const std::shared_ptr&lt; Module &gt; &amp;module, const std::string &amp;path)'],['../classcsyn_1_1_c_syn_manager.html#a437b12a64b16271a0e4ed6a35dd54a25',1,'csyn::CSynManager::uploadModule(const std::shared_ptr&lt; Module &gt; &amp;module, const std::string &amp;path, int major, int minor)']]],
  ['utils_168',['Utils',['../classcsyn_1_1_utils.html',1,'csyn']]]
];
