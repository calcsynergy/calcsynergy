var searchData=
[
  ['kernel_220',['Kernel',['../classcsyn_1_1_kernel.html',1,'csyn']]],
  ['kernellist_221',['KernelList',['../classcsyn_1_1_kernel_list.html',1,'csyn']]]
];
