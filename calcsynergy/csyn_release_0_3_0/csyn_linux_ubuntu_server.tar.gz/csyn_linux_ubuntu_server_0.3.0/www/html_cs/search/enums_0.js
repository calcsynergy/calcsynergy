var searchData=
[
  ['datatype_390',['DataType',['../namespace_c_syn.html#a11de1c2eb1d998aab5bb06e747d72a39',1,'CSyn']]]
];
