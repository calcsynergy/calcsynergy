var searchData=
[
  ['kernel_222',['Kernel',['../classcsyn_1_1_kernel.html',1,'csyn']]],
  ['kernellist_223',['KernelList',['../classcsyn_1_1_kernel_list.html',1,'csyn']]]
];
