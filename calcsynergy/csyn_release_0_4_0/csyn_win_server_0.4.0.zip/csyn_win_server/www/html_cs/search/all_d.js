var searchData=
[
  ['task_170',['Task',['../class_c_syn_1_1_task.html',1,'CSyn.Task'],['../class_c_syn_1_1_task.html#a5f6086bd3eda1545f10f6a2c0c998556',1,'CSyn.Task.Task()']]],
  ['taskexecutionstatus_171',['TaskExecutionStatus',['../namespace_c_syn.html#aed23ef04f22f3bc8be5e12c0cc04171d',1,'CSyn']]],
  ['taskresult_172',['TaskResult',['../class_c_syn_1_1_task_result.html',1,'CSyn.TaskResult'],['../class_c_syn_1_1_task_result.html#a8c61ad5d9896eee3834f7c71874a8fde',1,'CSyn.TaskResult.TaskResult(string taskName, string uuid, List&lt; Value &gt; valueList)'],['../class_c_syn_1_1_task_result.html#a898d9ab5e72062496cb18759c7901adb',1,'CSyn.TaskResult.TaskResult(string taskName, string uuid)']]],
  ['taskstatus_173',['TaskStatus',['../class_c_syn_1_1_task_status.html',1,'CSyn.TaskStatus'],['../class_c_syn_1_1_task_status.html#a74319036706023c72279cf18b27056d2',1,'CSyn.TaskStatus.TaskStatus()']]]
];
