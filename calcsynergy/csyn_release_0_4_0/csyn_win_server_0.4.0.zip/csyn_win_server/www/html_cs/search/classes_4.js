var searchData=
[
  ['kernel_199',['Kernel',['../class_c_syn_1_1_kernel.html',1,'CSyn']]],
  ['kernellist_200',['KernelList',['../class_c_syn_1_1_kernel_list.html',1,'CSyn']]]
];
