var searchData=
[
  ['datatype_404',['DataType',['../namespace_c_syn.html#a5a0b4b4f24f5383194de39bf7df08f42',1,'CSyn']]]
];
