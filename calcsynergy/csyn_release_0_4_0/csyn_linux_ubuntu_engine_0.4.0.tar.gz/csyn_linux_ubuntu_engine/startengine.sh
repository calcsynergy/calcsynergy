#! /bin/sh
#
# A script for running the CSynEngine
#
#

if [ "$CSYN_ENGINE_BASE" = "" ] ; then
	CSYN_ENGINE_BASE=`pwd`
fi


RUNNER=./CSynEngine
RUNNERARGS="$@"
status=0

sh -c "cd $CSYN_ENGINE_BASE && LD_LIBRARY_PATH=.:$LD_LIBRARY_PATH $RUNNER $RUNNERARGS"
if [ $? -ne 0 ] ; then
	status=1
fi

echo ""
echo ""
echo "CSynEngine has been executed. Run status $status."
echo ""

exit $status
