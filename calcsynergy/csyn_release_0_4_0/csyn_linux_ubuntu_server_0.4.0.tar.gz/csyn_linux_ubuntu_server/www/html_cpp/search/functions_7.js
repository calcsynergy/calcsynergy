var searchData=
[
  ['kernel_347',['Kernel',['../classcsyn_1_1_kernel.html#a633dbaed17cecc766cd262832455c317',1,'csyn::Kernel']]],
  ['kernellist_348',['KernelList',['../classcsyn_1_1_kernel_list.html#a685aecdb4a9bf247c0ab23c227d87bd3',1,'csyn::KernelList::KernelList()'],['../classcsyn_1_1_kernel_list.html#a0d097e0df9f2f744a88f46b727851a1d',1,'csyn::KernelList::KernelList(const KernelList &amp;list)']]]
];
