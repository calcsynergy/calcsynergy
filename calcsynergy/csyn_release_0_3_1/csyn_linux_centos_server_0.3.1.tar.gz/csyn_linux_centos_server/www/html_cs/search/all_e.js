var searchData=
[
  ['uploadkernellist_167',['uploadKernelList',['../class_c_syn_1_1_c_syn_manager.html#add673ad971dde07526209aafb81e2ed9',1,'CSyn::CSynManager']]],
  ['uploadmodule_168',['uploadModule',['../class_c_syn_1_1_c_syn_manager.html#a059ea7e3a12db46c564aacb37e95d06d',1,'CSyn.CSynManager.uploadModule(Module module, string path)'],['../class_c_syn_1_1_c_syn_manager.html#a92ae7fee5adc14c3a4b41a2cce551541',1,'CSyn.CSynManager.uploadModule(Module module, string path, int major, int minor)']]],
  ['utils_169',['Utils',['../class_c_syn_1_1_utils.html',1,'CSyn']]]
];
