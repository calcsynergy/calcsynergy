var searchData=
[
  ['csynexception_226',['CSynException',['../class_c_syn_1_1_c_syn_exception.html#a6732366aaa1a5a3c918bc64e754cd0f0',1,'CSyn.CSynException.CSynException()'],['../class_c_syn_1_1_c_syn_exception.html#a94dcd12b63c3e336c969fbead9d936b1',1,'CSyn.CSynException.CSynException(string message)'],['../class_c_syn_1_1_c_syn_exception.html#a4dd065cefb6942717bf91aacb116119a',1,'CSyn.CSynException.CSynException(string message, Exception inner)']]],
  ['csynmanager_227',['CSynManager',['../class_c_syn_1_1_c_syn_manager.html#aae4f634ad3b444a2d184bab7d85bb8fc',1,'CSyn::CSynManager']]]
];
