var searchData=
[
  ['csyn_215',['CSyn',['../namespace_c_syn.html',1,'']]]
];
