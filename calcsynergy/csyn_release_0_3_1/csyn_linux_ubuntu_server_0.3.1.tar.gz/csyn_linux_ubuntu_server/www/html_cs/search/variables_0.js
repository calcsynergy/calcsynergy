var searchData=
[
  ['version_389',['version',['../class_c_syn_1_1_utils.html#a193dd62f309c27142fcf5c2a68225004',1,'CSyn::Utils']]]
];
