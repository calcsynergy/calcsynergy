var searchData=
[
  ['csyn_216',['CSyn',['../namespace_c_syn.html',1,'']]]
];
