var searchData=
[
  ['securitymanager_227',['SecurityManager',['../classcsyn_1_1_security_manager.html',1,'csyn']]]
];
