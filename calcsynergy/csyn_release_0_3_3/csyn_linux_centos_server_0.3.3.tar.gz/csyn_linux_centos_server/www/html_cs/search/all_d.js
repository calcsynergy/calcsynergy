var searchData=
[
  ['task_164',['Task',['../class_c_syn_1_1_task.html',1,'CSyn.Task'],['../class_c_syn_1_1_task.html#a5f6086bd3eda1545f10f6a2c0c998556',1,'CSyn.Task.Task()']]],
  ['taskexecutionstatus_165',['TaskExecutionStatus',['../namespace_c_syn.html#ae6cc908574ae08869a778eb31af3532c',1,'CSyn']]],
  ['taskresult_166',['TaskResult',['../class_c_syn_1_1_task_result.html',1,'CSyn.TaskResult'],['../class_c_syn_1_1_task_result.html#aad99326559e99ad75248ae381e349101',1,'CSyn.TaskResult.TaskResult(string taskName, string uuid, List&lt; Parameter &gt; parameterList)'],['../class_c_syn_1_1_task_result.html#a898d9ab5e72062496cb18759c7901adb',1,'CSyn.TaskResult.TaskResult(string taskName, string uuid)']]],
  ['taskstatus_167',['TaskStatus',['../class_c_syn_1_1_task_status.html',1,'CSyn.TaskStatus'],['../class_c_syn_1_1_task_status.html#a74319036706023c72279cf18b27056d2',1,'CSyn.TaskStatus.TaskStatus()']]]
];
