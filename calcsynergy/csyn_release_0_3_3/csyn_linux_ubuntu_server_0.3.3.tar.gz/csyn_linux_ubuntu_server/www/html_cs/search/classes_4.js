var searchData=
[
  ['kernel_193',['Kernel',['../class_c_syn_1_1_kernel.html',1,'CSyn']]],
  ['kernellist_194',['KernelList',['../class_c_syn_1_1_kernel_list.html',1,'CSyn']]]
];
