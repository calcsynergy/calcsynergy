var searchData=
[
  ['task_200',['Task',['../class_c_syn_1_1_task.html',1,'CSyn']]],
  ['taskresult_201',['TaskResult',['../class_c_syn_1_1_task_result.html',1,'CSyn']]],
  ['taskstatus_202',['TaskStatus',['../class_c_syn_1_1_task_status.html',1,'CSyn']]]
];
