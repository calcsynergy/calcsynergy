var searchData=
[
  ['job_342',['Job',['../classcsyn_1_1_job.html#a5c1448d0773834f89bd94abeba9240dc',1,'csyn::Job']]],
  ['jobresult_343',['JobResult',['../classcsyn_1_1_job_result.html#a90d45d592f74ee79ecfcb34256203f39',1,'csyn::JobResult']]],
  ['jobstatus_344',['JobStatus',['../classcsyn_1_1_job_status.html#a2f3b3cae4968aedaab35568479012f1e',1,'csyn::JobStatus']]]
];
