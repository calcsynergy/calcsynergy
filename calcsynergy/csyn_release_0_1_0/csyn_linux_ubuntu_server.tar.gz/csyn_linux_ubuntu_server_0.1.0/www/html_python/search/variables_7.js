var searchData=
[
  ['job_5fname_234',['job_name',['../classcsyn_1_1_job.html#ad2198f41b5aaa5e79cc44f01e2825ca1',1,'csyn.Job.job_name()'],['../classcsyn_1_1_job_status.html#a8901dded322c5187a156c4d6eb3c798e',1,'csyn.JobStatus.job_name()'],['../classcsyn_1_1_job_result.html#ab9a7fe94e87759d2b9620e1941968a5f',1,'csyn.JobResult.job_name()']]]
];
