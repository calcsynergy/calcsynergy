var searchData=
[
  ['regs_5fper_5fblock_95',['regs_per_block',['../classcsyn_1_1_device.html#aab03d3b279b512715ed090d70575a6ee',1,'csyn::Device']]],
  ['remove_5fkernel_96',['remove_kernel',['../classcsyn_1_1_job_manager.html#a9339078936a2c46a715bf2d036e83fbc',1,'csyn::JobManager']]],
  ['remove_5fkernel_5flist_97',['remove_kernel_list',['../classcsyn_1_1_job_manager.html#ae8b723ab53d88e74e404f590c4177e49',1,'csyn::JobManager']]],
  ['remove_5fmodule_98',['remove_module',['../classcsyn_1_1_job_manager.html#a7c728f1b55a8a56a7fbf3f8685fb6825',1,'csyn::JobManager']]],
  ['response_99',['Response',['../classcsyn_1_1_response.html',1,'csyn']]],
  ['run_5fjob_100',['run_job',['../classcsyn_1_1_job_manager.html#add0d113a2e801be75bc3db8f3fbcf2b0',1,'csyn::JobManager']]],
  ['run_5fjob_5fasync_101',['run_job_async',['../classcsyn_1_1_job_manager.html#a4e185af3c07b863c2d2a52f590cf35f7',1,'csyn::JobManager']]]
];
