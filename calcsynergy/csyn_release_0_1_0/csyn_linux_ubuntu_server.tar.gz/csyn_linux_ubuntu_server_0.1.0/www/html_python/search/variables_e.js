var searchData=
[
  ['shared_5fmem_5fper_5fblock_268',['shared_mem_per_block',['../classcsyn_1_1_device.html#ae33577667659fc011e27e67afd0ea934',1,'csyn::Device']]],
  ['sharedmemory_269',['sharedMemory',['../classcsyn_1_1_task.html#a6ab0a1bd72c2a1ed265c3804976eb423',1,'csyn.Task.sharedMemory()'],['../classcsyn_1_1_job.html#a3ab1fe97036c4428dbfa8fc05616f865',1,'csyn.Job.sharedMemory()']]],
  ['start_5ftime_270',['start_time',['../classcsyn_1_1_task_status.html#a24fe6e3205979b375220c070cbdf1006',1,'csyn.TaskStatus.start_time()'],['../classcsyn_1_1_job_status.html#aecbd5d724450bfaeec98a814736ae002',1,'csyn.JobStatus.start_time()']]]
];
