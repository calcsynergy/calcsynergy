var searchData=
[
  ['remove_5fkernel_198',['remove_kernel',['../classcsyn_1_1_job_manager.html#a9339078936a2c46a715bf2d036e83fbc',1,'csyn::JobManager']]],
  ['remove_5fkernel_5flist_199',['remove_kernel_list',['../classcsyn_1_1_job_manager.html#ae8b723ab53d88e74e404f590c4177e49',1,'csyn::JobManager']]],
  ['remove_5fmodule_200',['remove_module',['../classcsyn_1_1_job_manager.html#a7c728f1b55a8a56a7fbf3f8685fb6825',1,'csyn::JobManager']]],
  ['run_5fjob_201',['run_job',['../classcsyn_1_1_job_manager.html#add0d113a2e801be75bc3db8f3fbcf2b0',1,'csyn::JobManager']]],
  ['run_5fjob_5fasync_202',['run_job_async',['../classcsyn_1_1_job_manager.html#a4e185af3c07b863c2d2a52f590cf35f7',1,'csyn::JobManager']]]
];
