var searchData=
[
  ['regs_5fper_5fblock_267',['regs_per_block',['../classcsyn_1_1_device.html#aab03d3b279b512715ed090d70575a6ee',1,'csyn::Device']]]
];
