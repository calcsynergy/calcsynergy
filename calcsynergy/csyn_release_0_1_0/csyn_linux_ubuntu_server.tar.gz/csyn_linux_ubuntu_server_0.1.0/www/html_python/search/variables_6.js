var searchData=
[
  ['id_232',['id',['../classcsyn_1_1_device.html#ae6e9736fb25c8fc6bb2700a126113ba8',1,'csyn::Device']]],
  ['ip_5faddress_233',['ip_address',['../classcsyn_1_1_device.html#ac73c44a590fba4f2b6e092187f6ea094',1,'csyn.Device.ip_address()'],['../classcsyn_1_1_task_status.html#adc8423d26cdf363c7976e0737d003d5a',1,'csyn.TaskStatus.ip_address()']]]
];
