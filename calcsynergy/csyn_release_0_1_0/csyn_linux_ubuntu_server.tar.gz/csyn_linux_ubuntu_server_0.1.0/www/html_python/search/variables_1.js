var searchData=
[
  ['blockdimx_212',['blockDimX',['../classcsyn_1_1_task.html#a10444865851a87d44928a389abe5b5ee',1,'csyn.Task.blockDimX()'],['../classcsyn_1_1_job.html#ad83b0be3c7be3a0f0dae3cc165017411',1,'csyn.Job.blockDimX()']]],
  ['blockdimy_213',['blockDimY',['../classcsyn_1_1_task.html#aaa76c5700c63453f74cb208f823c5d42',1,'csyn.Task.blockDimY()'],['../classcsyn_1_1_job.html#a2c87918ae58c5d7d624882e2bb129f3c',1,'csyn.Job.blockDimY()']]],
  ['blockdimz_214',['blockDimZ',['../classcsyn_1_1_task.html#aa6a2cc45058e7465efe688ebb1bc3a6c',1,'csyn.Task.blockDimZ()'],['../classcsyn_1_1_job.html#a32525716fc88fe3bb6a2922716172153',1,'csyn.Job.blockDimZ()']]]
];
