var searchData=
[
  ['task_5flist_271',['task_list',['../classcsyn_1_1_job.html#adaf3473b7b38902c50e5e90cf901b4ec',1,'csyn::Job']]],
  ['task_5fname_272',['task_name',['../classcsyn_1_1_task.html#ad4d6b0de8ba859d13b46fbf330462369',1,'csyn.Task.task_name()'],['../classcsyn_1_1_task_status.html#a0d0ca0aa5b96c46320ab729324101050',1,'csyn.TaskStatus.task_name()'],['../classcsyn_1_1_task_result.html#a6e9c5e6ce2e00d585225c9834f6c68c7',1,'csyn.TaskResult.task_name()']]],
  ['task_5fresult_5flist_273',['task_result_list',['../classcsyn_1_1_job_result.html#ad1294dcf038d64cc791dade9f76d2c0f',1,'csyn::JobResult']]],
  ['task_5fstatus_5flist_274',['task_status_list',['../classcsyn_1_1_job_status.html#a76a44b8f6962393938fe692dd262601e',1,'csyn::JobStatus']]],
  ['total_5fconst_5fmem_275',['total_const_mem',['../classcsyn_1_1_device.html#a04c94feb733c369e36791e6b27a24f3e',1,'csyn::Device']]],
  ['total_5fglobal_5fmem_276',['total_global_mem',['../classcsyn_1_1_device.html#afca6cf08d931cafac2a7f0eb5689246b',1,'csyn::Device']]]
];
