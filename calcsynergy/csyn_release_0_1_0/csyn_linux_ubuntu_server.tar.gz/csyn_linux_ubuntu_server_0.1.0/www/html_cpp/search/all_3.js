var searchData=
[
  ['entity_15',['Entity',['../classcsyn_1_1_entity.html',1,'csyn::Entity'],['../classcsyn_1_1_entity.html#a90760e290895e15e93713f694384d9bc',1,'csyn::Entity::Entity()']]]
];
