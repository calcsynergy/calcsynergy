var searchData=
[
  ['parameter_216',['Parameter',['../classcsyn_1_1_parameter.html',1,'csyn']]],
  ['property_217',['Property',['../classcsyn_1_1_property.html',1,'csyn']]]
];
