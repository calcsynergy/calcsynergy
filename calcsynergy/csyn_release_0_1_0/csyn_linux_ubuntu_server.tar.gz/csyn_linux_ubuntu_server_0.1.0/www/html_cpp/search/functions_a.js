var searchData=
[
  ['removekernel_338',['removeKernel',['../classcsyn_1_1_c_syn_manager.html#aac3983be18dbd4c28f3698a38e42c8fe',1,'csyn::CSynManager']]],
  ['removekernellist_339',['removeKernelList',['../classcsyn_1_1_c_syn_manager.html#ab1f5abd675252befbd0ef3d35367f05e',1,'csyn::CSynManager']]],
  ['removemodule_340',['removeModule',['../classcsyn_1_1_c_syn_manager.html#aa0bf637c333b6c011307d73ba8929892',1,'csyn::CSynManager']]],
  ['runjob_341',['runJob',['../classcsyn_1_1_c_syn_manager.html#a6968c813e5008cc7091078ecbf9a75be',1,'csyn::CSynManager']]],
  ['runjobasync_342',['runJobAsync',['../classcsyn_1_1_c_syn_manager.html#a35a53a9f2f826bbef529c51bcd222891',1,'csyn::CSynManager']]]
];
