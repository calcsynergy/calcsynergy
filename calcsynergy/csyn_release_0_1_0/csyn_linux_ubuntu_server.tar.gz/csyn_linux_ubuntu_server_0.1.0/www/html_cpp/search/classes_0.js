var searchData=
[
  ['csynmanager_205',['CSynManager',['../classcsyn_1_1_c_syn_manager.html',1,'csyn']]]
];
