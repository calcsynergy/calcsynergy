var searchData=
[
  ['kernel_153',['Kernel',['../classcsyn_1_1_kernel.html',1,'csyn']]],
  ['kernellist_154',['KernelList',['../classcsyn_1_1_kernel_list.html',1,'csyn']]]
];
