var searchData=
[
  ['name_258',['name',['../classcsyn_1_1_device.html#aba48a749dda0ed1d9e2a52d2f8b719c6',1,'csyn::Device']]]
];
