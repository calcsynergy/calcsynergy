var searchData=
[
  ['create_5fcubin_5fmodule_181',['create_cubin_module',['../classcsyn_1_1_job_manager.html#a6bfc64e4adf77a161ba7b3f6f4fabcb4',1,'csyn::JobManager']]],
  ['create_5ffat_5fcubin_5fmodule_182',['create_fat_cubin_module',['../classcsyn_1_1_job_manager.html#acb177c91bd74a8d30024d793d1bf30d9',1,'csyn::JobManager']]],
  ['create_5fkernel_5flist_183',['create_kernel_list',['../classcsyn_1_1_job_manager.html#a9cfd6c4a1e2f8e8a4ceac66f240c91a6',1,'csyn::JobManager']]]
];
