var searchData=
[
  ['uuid_277',['uuid',['../classcsyn_1_1_task_status.html#a44c4b36cc2516b3417f7a1e9e87f72c4',1,'csyn.TaskStatus.uuid()'],['../classcsyn_1_1_task_result.html#a3722e6cba9c4d85a150d66e55e44beb5',1,'csyn.TaskResult.uuid()'],['../classcsyn_1_1_job_status.html#ab2f6daca26df7997d606b22a5b830b7a',1,'csyn.JobStatus.uuid()'],['../classcsyn_1_1_job_result.html#afbc981b1c674d4971c256ec4c4314352',1,'csyn.JobResult.uuid()']]]
];
