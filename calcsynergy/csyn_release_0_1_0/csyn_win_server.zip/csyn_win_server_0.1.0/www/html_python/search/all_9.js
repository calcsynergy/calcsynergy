var searchData=
[
  ['kernel_56',['Kernel',['../classcsyn_1_1_kernel.html',1,'csyn.Kernel'],['../classcsyn_1_1_task.html#a5688e8568668f68cc1f9c90727de95bd',1,'csyn.Task.kernel()']]],
  ['kernel_5fdescription_57',['kernel_description',['../classcsyn_1_1_kernel.html#ac9dc0a639de6d1e51ba7dadad1015141',1,'csyn::Kernel']]],
  ['kernel_5fexec_5ftimeout_5fenabled_58',['kernel_exec_timeout_enabled',['../classcsyn_1_1_device.html#af31160f69a86a5d6d9d747bd89b43c25',1,'csyn::Device']]],
  ['kernel_5flist_59',['kernel_list',['../classcsyn_1_1_kernel_list.html#afd185822c59fbf88c66cd8e9911e78dd',1,'csyn::KernelList']]],
  ['kernel_5fname_60',['kernel_name',['../classcsyn_1_1_kernel.html#a0df718ce83b95b4f1a88f3990b2550ce',1,'csyn::Kernel']]],
  ['kernellist_61',['KernelList',['../classcsyn_1_1_kernel_list.html',1,'csyn']]],
  ['key_62',['key',['../classcsyn_1_1_property.html#ad995aec4634b6322a60d28e6c07916b4',1,'csyn::Property']]]
];
