var searchData=
[
  ['can_5fmap_5fhost_5fmemory_215',['can_map_host_memory',['../classcsyn_1_1_device.html#a4cac692de5b5e932167251d1145e87f1',1,'csyn::Device']]],
  ['clock_5frate_216',['clock_rate',['../classcsyn_1_1_device.html#abafdfa5a5a561a91d7f87e9c7129f0b0',1,'csyn::Device']]],
  ['concurrent_5fkernels_217',['concurrent_kernels',['../classcsyn_1_1_device.html#a6b654b3b4714891790c6d5e6a83ad1ea',1,'csyn::Device']]]
];
