var searchData=
[
  ['warp_5fsize_138',['warp_size',['../classcsyn_1_1_device.html#a56e429dde9a6255fdc5fc33428b5b7f9',1,'csyn::Device']]]
];
