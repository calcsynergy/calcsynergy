var searchData=
[
  ['csyn_179',['csyn',['../namespacecsyn.html',1,'']]]
];
