var searchData=
[
  ['global_5fvalue_5flist_227',['global_value_list',['../classcsyn_1_1_job.html#af6e5b55b4d860dc2549fcb4bcaba0db1',1,'csyn::Job']]],
  ['global_5fvalue_5fname_228',['global_value_name',['../classcsyn_1_1_parameter.html#aa87b2d0540c5019c42712c2daa4b9a39',1,'csyn::Parameter']]],
  ['griddimx_229',['gridDimX',['../classcsyn_1_1_task.html#a6c86a12976e728394cd58a8cc2e3b068',1,'csyn.Task.gridDimX()'],['../classcsyn_1_1_job.html#af87c4dead4751da925f61da174721896',1,'csyn.Job.gridDimX()']]],
  ['griddimy_230',['gridDimY',['../classcsyn_1_1_task.html#a335df2ad465975c8aacea14b41bf1faa',1,'csyn.Task.gridDimY()'],['../classcsyn_1_1_job.html#abaf1967a68a970dff72927bfbfee2cb3',1,'csyn.Job.gridDimY()']]],
  ['griddimz_231',['gridDimZ',['../classcsyn_1_1_task.html#aa9d48098724960c0880518c71187573b',1,'csyn.Task.gridDimZ()'],['../classcsyn_1_1_job.html#a99caee365bab9f6bd04788e9660990f6',1,'csyn.Job.gridDimZ()']]]
];
