var searchData=
[
  ['is_5fjob_5ffinished_196',['is_job_finished',['../classcsyn_1_1_job_status.html#af5ea5f0344d948828b06319df74a3042',1,'csyn::JobStatus']]]
];
