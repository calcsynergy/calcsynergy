self.__precacheManifest = [
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "ad69185ef9d7e3f06fa3",
    "url": "/static/js/main.942ca65d.chunk.js"
  },
  {
    "revision": "65371115b4762f062bb5",
    "url": "/static/js/2.8fd1ad73.chunk.js"
  },
  {
    "revision": "ad69185ef9d7e3f06fa3",
    "url": "/static/css/main.6c81662a.chunk.css"
  },
  {
    "revision": "60c45d95bf395995ca061d5195fde746",
    "url": "/index.html"
  }
];