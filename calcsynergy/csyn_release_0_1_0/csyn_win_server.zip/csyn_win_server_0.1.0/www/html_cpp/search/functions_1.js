var searchData=
[
  ['csynmanager_245',['CSynManager',['../classcsyn_1_1_c_syn_manager.html#afd4213e14440fcd3dbc099a0f3bb9c94',1,'csyn::CSynManager']]]
];
