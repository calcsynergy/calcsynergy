var searchData=
[
  ['task_201',['Task',['../class_c_syn_1_1_task.html',1,'CSyn']]],
  ['taskresult_202',['TaskResult',['../class_c_syn_1_1_task_result.html',1,'CSyn']]],
  ['taskstatus_203',['TaskStatus',['../class_c_syn_1_1_task_status.html',1,'CSyn']]]
];
