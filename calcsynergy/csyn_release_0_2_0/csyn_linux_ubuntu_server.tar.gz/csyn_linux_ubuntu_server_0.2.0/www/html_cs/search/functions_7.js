var searchData=
[
  ['kernel_317',['Kernel',['../class_c_syn_1_1_kernel.html#a2cc3f9cac1cc878b327fdae4a37d84cb',1,'CSyn::Kernel']]],
  ['kernellist_318',['KernelList',['../class_c_syn_1_1_kernel_list.html#a7558ac3a23bee6c88decf3b2efea3c07',1,'CSyn::KernelList']]]
];
