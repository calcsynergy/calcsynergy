var searchData=
[
  ['manager_399',['manager',['../class_c_syn_1_1_security_manager.html#aa9d562da750a46fab8e0639440bbc9cf',1,'CSyn::SecurityManager']]]
];
