var searchData=
[
  ['csyn_217',['CSyn',['../namespace_c_syn.html',1,'']]]
];
