var searchData=
[
  ['kernel_217',['Kernel',['../classcsyn_1_1_kernel.html',1,'csyn']]],
  ['kernellist_218',['KernelList',['../classcsyn_1_1_kernel_list.html',1,'csyn']]]
];
