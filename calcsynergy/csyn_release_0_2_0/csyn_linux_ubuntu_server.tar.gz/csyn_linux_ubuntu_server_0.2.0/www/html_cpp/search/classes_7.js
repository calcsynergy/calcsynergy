var searchData=
[
  ['securitymanager_223',['SecurityManager',['../classcsyn_1_1_security_manager.html',1,'csyn']]]
];
