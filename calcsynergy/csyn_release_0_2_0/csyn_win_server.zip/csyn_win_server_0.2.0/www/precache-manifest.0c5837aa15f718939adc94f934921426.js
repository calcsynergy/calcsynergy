self.__precacheManifest = [
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "4bd51b240edeb67c577c",
    "url": "/static/js/main.1a4c98c4.chunk.js"
  },
  {
    "revision": "65371115b4762f062bb5",
    "url": "/static/js/2.8fd1ad73.chunk.js"
  },
  {
    "revision": "4bd51b240edeb67c577c",
    "url": "/static/css/main.6c81662a.chunk.css"
  },
  {
    "revision": "f45e83429ce4d04f19b7c50678d2f8b0",
    "url": "/index.html"
  }
];