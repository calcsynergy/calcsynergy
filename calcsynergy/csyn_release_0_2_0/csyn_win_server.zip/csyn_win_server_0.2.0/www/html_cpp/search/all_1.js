var searchData=
[
  ['csynexception_10',['CSynException',['../classcsyn_1_1_c_syn_exception.html',1,'csyn::CSynException'],['../classcsyn_1_1_c_syn_exception.html#a9f68ebb4f95f1311cc982497953cdb42',1,'csyn::CSynException::CSynException()']]],
  ['csynmanager_11',['CSynManager',['../classcsyn_1_1_c_syn_manager.html',1,'csyn::CSynManager'],['../classcsyn_1_1_c_syn_manager.html#ae95caa2cad08088b4e0c2a094844be1d',1,'csyn::CSynManager::CSynManager()']]]
];
