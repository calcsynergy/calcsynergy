var searchData=
[
  ['entity_16',['Entity',['../classcsyn_1_1_entity.html',1,'csyn::Entity'],['../classcsyn_1_1_entity.html#a90760e290895e15e93713f694384d9bc',1,'csyn::Entity::Entity()']]],
  ['error_5fmessage_17',['error_message',['../classcsyn_1_1_c_syn_exception.html#a08b8591cbd5aac87f7d927d315689869',1,'csyn::CSynException']]]
];
