var searchData=
[
  ['parameter_198',['Parameter',['../class_c_syn_1_1_parameter.html',1,'CSyn']]],
  ['property_199',['Property',['../class_c_syn_1_1_property.html',1,'CSyn']]]
];
